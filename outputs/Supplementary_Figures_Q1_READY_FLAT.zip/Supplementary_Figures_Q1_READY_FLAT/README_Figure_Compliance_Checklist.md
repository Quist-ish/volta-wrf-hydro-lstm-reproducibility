# Nature / Elsevier Figure-Compliance Checklist for Supplementary Figures

## Submission decision
The AI-generated image files previously created with image-generation tools should be treated as concept drafts only, not final submission figures.

For Nature Portfolio and Elsevier submission, submit only figures generated from:
1. original data files,
2. reproducible Python/R/GIS scripts,
3. documented processing steps,
4. archived raw/intermediate data, and
5. captions that clearly state benchmark-relative interpretation.

## Figure-by-figure status

| Figure | Status | Action |
|---|---|---|
| Fig. S1 | Python-generated from available AMJJASO prediction CSV | Usable after confirming the prediction file is the final corrected domain-based series |
| Fig. S2 | Requires real LSTM training-history CSV | Do not use synthetic convergence curves |
| Fig. S3 | Python-generated from available AMJJASO prediction CSV | Usable after confirming the prediction file is final |
| Fig. S4 | Python-generated from PCA information CSV | Usable if PCA input represents final predictor set |
| Fig. S5 | Python-generated from corrected accepted RMSE values | Usable if these are the final manuscript values |
| Fig. S6 | Python-generated diagnostic synthesis from corrected values | Use as synthesis only; keep caption clear that scores are normalized |
| Fig. S7 | Requires real spatial rasters/grids | Do not use AI-generated maps |
| Fig. S8 | Requires final domain-based baseline metrics | Do not use point-based EL1/EL2 or ARIMA |

## Caption language rules
- Use: “G-RUN runoff/reanalysis benchmark”
- Do not use: “observed discharge” for G-RUN
- Use: “benchmark-relative comparison”
- Do not use: “independent validation with G-RUN”
- Use: “satellite-supported spatial flood diagnostics”
- Do not use: “hydraulic inundation validation” unless stating what the study does not do

## Required archive
Archive the final data, scripts, environment, and exact exported files with the submission package.
