"""
Supplementary figure generation code for:
Multi-source assessment of a hybrid WRF-Hydro-LSTM residual-correction framework
for AMJJASO high-flow reconstruction in the regulated Volta River Basin.

Purpose
-------
This script generates Q1-ready supplementary figures and recomputes benchmark-relative
metrics from final domain-based prediction files. It avoids ARIMA and point-based
Evaluation Location analysis. It treats G-RUN only as a runoff/reanalysis benchmark.

Expected prediction CSV columns for streamflow figures:
    date or time_index            optional; used for event plots if present
    g_run or benchmark            G-RUN runoff/reanalysis benchmark
    wrf or wrf_hydro              standalone WRF-Hydro discharge
    hybrid or lstm_hybrid         hybrid WRF-Hydro-LSTM discharge

Optional baseline CSV columns for Fig. S8:
    model, rmse, mae, r2, nse, kge, residual_variance, lag1_acf
    model names should include: WRF-Hydro, Persistence, LR-AR, LSTM

Generated outputs
-----------------
    Fig_S1_flow_duration.png
    Fig_S2_lstm_training_convergence.png
    Fig_S3_event_hydrograph.png
    Fig_S4_predictor_pca.png
    Fig_S5_corrected_amjjaso_rmse.png
    Fig_S6_corrected_radar_chart.png
    Fig_S7_spatial_frequency_template.png (from gridded arrays if available)
    Fig_S8_domain_baseline_comparison.png
    Table_S3_domain_baseline_metrics.csv

Example commands
----------------
python supplementary_figure_generation_code.py --predictions amjjaso_predictions.csv --outdir supp_figures
python supplementary_figure_generation_code.py --baseline baseline_metrics.csv --outdir supp_figures

Notes
-----
- Do not label G-RUN as observed discharge.
- Q90 is the primary high-flow target; Q95 is sensitivity only.
- ARIMA is excluded.
"""

import argparse
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# Corrected key values from the revised manuscript
CORRECTED = {
    "amjjaso_rmse_wrf": 1.411,
    "amjjaso_rmse_hybrid": 0.844,
    "amjjaso_rmse_reduction": 40.22,
    "amjjaso_mae_wrf": 1.091,
    "amjjaso_mae_hybrid": 0.606,
    "r2_wrf": 0.610,
    "r2_hybrid": 0.851,
    "nse_wrf": 0.574,
    "nse_hybrid": 0.848,
    "kge_wrf": 0.776,
    "kge_hybrid": 0.845,
    "q90_rmse_wrf": 2.284,
    "q90_rmse_hybrid": 1.693,
    "q90_rmse_reduction": 25.88,
    "q95_rmse_wrf": 2.486,
    "q95_rmse_hybrid": 2.102,
    "q95_rmse_reduction": 15.47,
    "flood_rmse_wrf": 1680.0,
    "flood_rmse_hybrid": 1420.0,
    "spatial_disagreement_wrf": 0.34,
    "spatial_disagreement_hybrid": 0.27,
    "benchmark_mean_flooded_area": 4591.0,
    "wrf_mean_flooded_area": 6200.0,
    "hybrid_mean_flooded_area": 5967.0,
    "mean_overestimation_reduction": 233.0,
    "trend_benchmark": 46.148,
    "trend_wrf": 65.280,
    "trend_hybrid": 62.678,
    "trend_bias_reduction": 13.60,
}

# -----------------------------------------------------------------------------
# General utilities
# -----------------------------------------------------------------------------
def ensure_outdir(outdir):
    outdir = Path(outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    return outdir


def normalize_columns(df):
    """Normalize likely column names without altering values."""
    lower = {c.lower().strip(): c for c in df.columns}
    aliases = {
        "benchmark": ["g_run", "grun", "g-run", "benchmark", "q_g_run", "q_bench", "observed"],
        "wrf": ["wrf", "wrf_hydro", "wrf-hydro", "q_wrf", "standalone", "wrfhydro"],
        "hybrid": ["hybrid", "lstm_hybrid", "wrf_lstm", "wrf-hydro-lstm", "q_hybrid"],
        "date": ["date", "time", "datetime", "time_index", "record_index"],
    }
    rename = {}
    for target, names in aliases.items():
        for name in names:
            if name in lower:
                rename[lower[name]] = target
                break
    return df.rename(columns=rename)


def rmse(obs, sim):
    obs = np.asarray(obs, dtype=float)
    sim = np.asarray(sim, dtype=float)
    return float(np.sqrt(np.nanmean((obs - sim) ** 2)))


def mae(obs, sim):
    obs = np.asarray(obs, dtype=float)
    sim = np.asarray(sim, dtype=float)
    return float(np.nanmean(np.abs(obs - sim)))


def r2(obs, sim):
    obs = np.asarray(obs, dtype=float)
    sim = np.asarray(sim, dtype=float)
    mask = np.isfinite(obs) & np.isfinite(sim)
    if mask.sum() < 3:
        return np.nan
    return float(np.corrcoef(obs[mask], sim[mask])[0, 1] ** 2)


def nse(obs, sim):
    obs = np.asarray(obs, dtype=float)
    sim = np.asarray(sim, dtype=float)
    den = np.nansum((obs - np.nanmean(obs)) ** 2)
    if den == 0:
        return np.nan
    return float(1 - np.nansum((obs - sim) ** 2) / den)


def kge(obs, sim):
    obs = np.asarray(obs, dtype=float)
    sim = np.asarray(sim, dtype=float)
    mask = np.isfinite(obs) & np.isfinite(sim)
    if mask.sum() < 3:
        return np.nan
    o = obs[mask]
    s = sim[mask]
    r = np.corrcoef(o, s)[0, 1]
    alpha = np.std(s, ddof=1) / np.std(o, ddof=1) if np.std(o, ddof=1) != 0 else np.nan
    beta = np.mean(s) / np.mean(o) if np.mean(o) != 0 else np.nan
    return float(1 - np.sqrt((r - 1) ** 2 + (alpha - 1) ** 2 + (beta - 1) ** 2))


def lag1_acf(x):
    x = np.asarray(x, dtype=float)
    mask = np.isfinite(x)
    x = x[mask]
    if len(x) < 3:
        return np.nan
    return float(np.corrcoef(x[:-1], x[1:])[0, 1])


def metrics_table(benchmark, series_dict):
    rows = []
    for name, sim in series_dict.items():
        residual = np.asarray(benchmark, dtype=float) - np.asarray(sim, dtype=float)
        rows.append({
            "model": name,
            "rmse": rmse(benchmark, sim),
            "mae": mae(benchmark, sim),
            "r2": r2(benchmark, sim),
            "nse": nse(benchmark, sim),
            "kge": kge(benchmark, sim),
            "residual_variance": float(np.nanvar(residual)),
            "lag1_acf": lag1_acf(residual),
        })
    out = pd.DataFrame(rows)
    wrf_rmse = out.loc[out["model"].str.lower().str.contains("wrf"), "rmse"].iloc[0]
    out["rmse_reduction_percent"] = (wrf_rmse - out["rmse"]) / wrf_rmse * 100
    return out

# -----------------------------------------------------------------------------
# Figure S1: Flow-duration comparison
# -----------------------------------------------------------------------------
def plot_flow_duration(pred_csv, outdir):
    df = normalize_columns(pd.read_csv(pred_csv))
    required = {"benchmark", "wrf", "hybrid"}
    if not required.issubset(df.columns):
        raise ValueError(f"Prediction CSV must contain columns compatible with {required}. Found {df.columns.tolist()}")
    outdir = ensure_outdir(outdir)
    plt.figure(figsize=(7.2, 4.8))
    for col, label in [("benchmark", "G-RUN runoff/reanalysis benchmark"), ("wrf", "Standalone WRF-Hydro"), ("hybrid", "Hybrid WRF-Hydro-LSTM")]:
        values = np.sort(df[col].dropna().to_numpy())[::-1]
        exc = np.arange(1, len(values) + 1) / (len(values) + 1) * 100
        plt.plot(exc, values, label=label, linewidth=1.8)
    plt.yscale("log")
    plt.xlabel("Exceedance probability (%)")
    plt.ylabel("Benchmark-relative discharge")
    plt.title("Fig. S1. AMJJASO flow-duration comparison")
    plt.legend(frameon=False, fontsize=8)
    plt.grid(True, which="both", alpha=0.25)
    plt.tight_layout()
    path = outdir / "Fig_S1_flow_duration.png"
    plt.savefig(path, dpi=350)
    plt.close()
    return path

# -----------------------------------------------------------------------------
# Figure S2: LSTM convergence
# -----------------------------------------------------------------------------
def plot_training_convergence(training_csv, outdir):
    df = pd.read_csv(training_csv)
    outdir = ensure_outdir(outdir)
    fig = plt.figure(figsize=(8.0, 3.5))
    ax1 = fig.add_subplot(1, 2, 1)
    ax2 = fig.add_subplot(1, 2, 2)
    epoch = df["epoch"] if "epoch" in df.columns else np.arange(len(df))
    if {"training_loss", "validation_loss"}.issubset(df.columns):
        ax1.plot(epoch, df["training_loss"], label="Training MSE")
        ax1.plot(epoch, df["validation_loss"], label="Validation MSE")
    ax1.set_title("MSE loss")
    ax1.set_xlabel("Epoch")
    ax1.set_ylabel("Loss")
    ax1.legend(frameon=False, fontsize=8)
    ax1.grid(True, alpha=0.25)
    if {"training_mae", "validation_mae"}.issubset(df.columns):
        ax2.plot(epoch, df["training_mae"], label="Training MAE")
        ax2.plot(epoch, df["validation_mae"], label="Validation MAE")
    ax2.set_title("MAE")
    ax2.set_xlabel("Epoch")
    ax2.set_ylabel("MAE")
    ax2.legend(frameon=False, fontsize=8)
    ax2.grid(True, alpha=0.25)
    fig.suptitle("Fig. S2. LSTM benchmark-relative residual-learning convergence")
    fig.tight_layout()
    path = outdir / "Fig_S2_lstm_training_convergence.png"
    plt.savefig(path, dpi=350)
    plt.close()
    return path

# -----------------------------------------------------------------------------
# Figure S3: Event hydrograph diagnostics
# -----------------------------------------------------------------------------
def plot_event_hydrograph(pred_csv, outdir, start=None, end=None):
    df = normalize_columns(pd.read_csv(pred_csv))
    outdir = ensure_outdir(outdir)
    x = np.arange(len(df)) if "date" not in df.columns else df["date"]
    if start is not None or end is not None:
        df = df.iloc[start:end]
        x = np.arange(len(df)) if "date" not in df.columns else df["date"]
    fig, axes = plt.subplots(3, 1, figsize=(9.0, 7.0), sharex=False)
    windows = [(0, len(df)), (0, min(100, len(df))), (max(0, len(df)//2 - 40), min(len(df), len(df)//2 + 40))]
    titles = ["Complete AMJJASO series", "Zoom: first 100 AMJJASO records", "Zoom: representative flood-event window"]
    for ax, (a,b), title in zip(axes, windows, titles):
        sub = df.iloc[a:b]
        xx = np.arange(a, b)
        ax.plot(xx, sub["benchmark"], label="G-RUN runoff/reanalysis benchmark", linewidth=1.5)
        ax.plot(xx, sub["wrf"], label="Standalone WRF-Hydro", linewidth=1.2, linestyle="--")
        ax.plot(xx, sub["hybrid"], label="Hybrid WRF-Hydro-LSTM", linewidth=1.5)
        ax.set_title(title)
        ax.set_ylabel("Benchmark-relative discharge")
        ax.grid(True, alpha=0.25)
    axes[-1].set_xlabel("AMJJASO record index")
    axes[0].legend(frameon=False, fontsize=8, ncol=3)
    fig.suptitle("Fig. S3. Event-scale benchmark-relative hydrograph diagnostics")
    fig.tight_layout()
    path = outdir / "Fig_S3_event_hydrograph.png"
    plt.savefig(path, dpi=350)
    plt.close()
    return path

# -----------------------------------------------------------------------------
# Figure S4: PCA feature-space diagnostics
# -----------------------------------------------------------------------------
def plot_pca(pca_csv, outdir):
    df = pd.read_csv(pca_csv)
    if "explained_variance_ratio" not in df.columns:
        raise ValueError("PCA CSV must contain 'explained_variance_ratio'.")
    values = df["explained_variance_ratio"].to_numpy(dtype=float)
    pcs = np.arange(1, len(values) + 1)
    cum = np.cumsum(values)
    outdir = ensure_outdir(outdir)
    plt.figure(figsize=(6.8, 4.5))
    plt.bar(pcs, values, label="Individual")
    plt.plot(pcs, cum, marker="o", label="Cumulative")
    plt.xlabel("Principal component")
    plt.ylabel("Explained variance ratio")
    plt.title("Fig. S4. Predictor PCA explained variance")
    plt.ylim(0, 1.05)
    plt.grid(True, axis="y", alpha=0.25)
    plt.legend(frameon=False)
    plt.tight_layout()
    path = outdir / "Fig_S4_predictor_pca.png"
    plt.savefig(path, dpi=350)
    plt.close()
    return path

# -----------------------------------------------------------------------------
# Figure S5: Corrected AMJJASO RMSE comparison
# -----------------------------------------------------------------------------
def plot_corrected_rmse(outdir):
    outdir = ensure_outdir(outdir)
    labels = ["Standalone WRF-Hydro", "Hybrid WRF-Hydro-LSTM"]
    values = [CORRECTED["amjjaso_rmse_wrf"], CORRECTED["amjjaso_rmse_hybrid"]]
    plt.figure(figsize=(6.5, 3.6))
    bars = plt.barh(labels, values)
    for bar, val in zip(bars, values):
        plt.text(val + 0.03, bar.get_y() + bar.get_height()/2, f"{val:.3f}", va="center")
    plt.xlabel("RMSE (benchmark-relative units)")
    plt.title("Fig. S5. Corrected AMJJASO RMSE comparison")
    plt.text(max(values) * 0.55, 0.55, "RMSE reduction = 40.22%", bbox=dict(facecolor="white", edgecolor="0.6"))
    plt.grid(True, axis="x", alpha=0.25)
    plt.tight_layout()
    path = outdir / "Fig_S5_corrected_amjjaso_rmse.png"
    plt.savefig(path, dpi=350)
    plt.close()
    return path

# -----------------------------------------------------------------------------
# Figure S6: Corrected radar chart
# -----------------------------------------------------------------------------
def plot_corrected_radar(outdir):
    outdir = ensure_outdir(outdir)
    metrics = ["RMSE\n(lower)", "MAE\n(lower)", "R²\n(higher)", "NSE\n(higher)", "KGE\n(higher)", "RMSE reduction\n(higher)"]
    # Normalize so higher score is always better. Values are illustrative and based on corrected metrics.
    wrf_raw = np.array([CORRECTED["amjjaso_rmse_wrf"], CORRECTED["amjjaso_mae_wrf"], CORRECTED["r2_wrf"], CORRECTED["nse_wrf"], CORRECTED["kge_wrf"], 0.0])
    hyb_raw = np.array([CORRECTED["amjjaso_rmse_hybrid"], CORRECTED["amjjaso_mae_hybrid"], CORRECTED["r2_hybrid"], CORRECTED["nse_hybrid"], CORRECTED["kge_hybrid"], CORRECTED["amjjaso_rmse_reduction"]/100])
    # For error metrics invert relative to max.
    max_rmse = max(wrf_raw[0], hyb_raw[0])
    max_mae = max(wrf_raw[1], hyb_raw[1])
    wrf = np.array([1 - wrf_raw[0]/max_rmse, 1 - wrf_raw[1]/max_mae, wrf_raw[2], wrf_raw[3], wrf_raw[4], wrf_raw[5]])
    hyb = np.array([1 - hyb_raw[0]/max_rmse, 1 - hyb_raw[1]/max_mae, hyb_raw[2], hyb_raw[3], hyb_raw[4], hyb_raw[5]])
    # Rescale first two to 0-1 among models for visual clarity.
    wrf[0], hyb[0] = 0.0, 1.0
    wrf[1], hyb[1] = 0.0, 1.0
    angles = np.linspace(0, 2*np.pi, len(metrics), endpoint=False).tolist()
    wrf = np.r_[wrf, wrf[0]]
    hyb = np.r_[hyb, hyb[0]]
    angles += angles[:1]
    fig = plt.figure(figsize=(6.0, 6.0))
    ax = plt.subplot(111, polar=True)
    ax.plot(angles, wrf, marker="o", label="Standalone WRF-Hydro")
    ax.fill(angles, wrf, alpha=0.15)
    ax.plot(angles, hyb, marker="o", label="Hybrid WRF-Hydro-LSTM")
    ax.fill(angles, hyb, alpha=0.15)
    ax.set_xticks(angles[:-1])
    ax.set_xticklabels(metrics)
    ax.set_ylim(0, 1)
    ax.set_title("Fig. S6. Corrected aggregate model-performance radar chart", pad=20)
    ax.legend(loc="upper right", bbox_to_anchor=(1.35, 1.15), frameon=False)
    plt.tight_layout()
    path = outdir / "Fig_S6_corrected_radar_chart.png"
    plt.savefig(path, dpi=350)
    plt.close()
    return path

# -----------------------------------------------------------------------------
# Figure S7: Spatial frequency maps (template from gridded arrays)
# -----------------------------------------------------------------------------
def plot_spatial_frequency_template(npz_path, outdir):
    """Plot spatial maps if an npz contains arrays: benchmark, wrf_minus_benchmark, hybrid_minus_benchmark."""
    data = np.load(npz_path)
    required = ["benchmark", "wrf_minus_benchmark", "hybrid_minus_benchmark"]
    if not all(k in data for k in required):
        raise ValueError(f"NPZ must contain arrays: {required}")
    outdir = ensure_outdir(outdir)
    fig, axes = plt.subplots(1, 3, figsize=(10, 3.5))
    im0 = axes[0].imshow(data["benchmark"], origin="lower")
    axes[0].set_title("Benchmark-derived flood frequency")
    plt.colorbar(im0, ax=axes[0], fraction=0.046)
    im1 = axes[1].imshow(data["wrf_minus_benchmark"], origin="lower", vmin=-0.3, vmax=0.3, cmap="RdBu_r")
    axes[1].set_title("WRF-Hydro minus benchmark")
    plt.colorbar(im1, ax=axes[1], fraction=0.046)
    im2 = axes[2].imshow(data["hybrid_minus_benchmark"], origin="lower", vmin=-0.3, vmax=0.3, cmap="RdBu_r")
    axes[2].set_title("Hybrid minus benchmark")
    plt.colorbar(im2, ax=axes[2], fraction=0.046)
    for ax in axes:
        ax.set_xticks([])
        ax.set_yticks([])
    fig.suptitle("Fig. S7. Extended benchmark-relative spatial flood-frequency maps")
    fig.tight_layout()
    path = outdir / "Fig_S7_spatial_frequency_template.png"
    plt.savefig(path, dpi=350)
    plt.close()
    return path

# -----------------------------------------------------------------------------
# Figure S8: Domain baseline comparison excluding ARIMA
# -----------------------------------------------------------------------------
def plot_domain_baseline_comparison(baseline_csv, outdir):
    df = pd.read_csv(baseline_csv)
    df = df[~df["model"].str.lower().str.contains("arima", na=False)].copy()
    order = ["WRF-Hydro", "Persistence", "LR-AR", "LSTM"]
    df["order"] = df["model"].apply(lambda x: order.index(x) if x in order else 99)
    df = df.sort_values("order")
    outdir = ensure_outdir(outdir)
    plt.figure(figsize=(6.8, 4.0))
    bars = plt.bar(df["model"], df["rmse"])
    for bar, val in zip(bars, df["rmse"]):
        plt.text(bar.get_x()+bar.get_width()/2, val + 0.02, f"{val:.3f}", ha="center", va="bottom")
    plt.ylabel("Held-out AMJJASO RMSE")
    plt.xlabel("Residual-correction model")
    plt.title("Fig. S8. Domain-based residual-baseline comparison")
    plt.grid(True, axis="y", alpha=0.25)
    plt.tight_layout()
    path = outdir / "Fig_S8_domain_baseline_comparison.png"
    plt.savefig(path, dpi=350)
    plt.close()
    # Also save table
    df.drop(columns=["order"], errors="ignore").to_csv(outdir / "Table_S3_domain_baseline_metrics.csv", index=False)
    return path

# -----------------------------------------------------------------------------
# Demo outputs using corrected values only
# -----------------------------------------------------------------------------
def create_demo_baseline_csv(outdir):
    outdir = ensure_outdir(outdir)
    # Persistence and LR-AR rows are intentionally left as NaN unless final predictions are supplied.
    df = pd.DataFrame([
        {"model":"WRF-Hydro", "rmse":CORRECTED["amjjaso_rmse_wrf"], "mae":CORRECTED["amjjaso_mae_wrf"], "r2":CORRECTED["r2_wrf"], "nse":CORRECTED["nse_wrf"], "kge":CORRECTED["kge_wrf"]},
        {"model":"Persistence", "rmse":np.nan, "mae":np.nan, "r2":np.nan, "nse":np.nan, "kge":np.nan},
        {"model":"LR-AR", "rmse":np.nan, "mae":np.nan, "r2":np.nan, "nse":np.nan, "kge":np.nan},
        {"model":"LSTM", "rmse":CORRECTED["amjjaso_rmse_hybrid"], "mae":CORRECTED["amjjaso_mae_hybrid"], "r2":CORRECTED["r2_hybrid"], "nse":CORRECTED["nse_hybrid"], "kge":CORRECTED["kge_hybrid"]},
    ])
    path = outdir / "Table_S3_domain_baseline_metrics_template.csv"
    df.to_csv(path, index=False)
    return path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--predictions", help="CSV with G-RUN benchmark, WRF-Hydro, and hybrid series")
    parser.add_argument("--training", help="CSV with epoch, training_loss, validation_loss, training_mae, validation_mae")
    parser.add_argument("--pca", help="CSV with explained_variance_ratio column")
    parser.add_argument("--baseline", help="CSV with model and rmse columns; ARIMA rows are excluded if present")
    parser.add_argument("--spatial_npz", help="NPZ with benchmark, wrf_minus_benchmark, hybrid_minus_benchmark arrays")
    parser.add_argument("--outdir", default="supplementary_figures")
    args = parser.parse_args()

    outdir = ensure_outdir(args.outdir)
    generated = []
    generated.append(plot_corrected_rmse(outdir))
    generated.append(plot_corrected_radar(outdir))
    create_demo_baseline_csv(outdir)

    if args.predictions:
        generated.append(plot_flow_duration(args.predictions, outdir))
        generated.append(plot_event_hydrograph(args.predictions, outdir))
        df = normalize_columns(pd.read_csv(args.predictions))
        if {"benchmark", "wrf", "hybrid"}.issubset(df.columns):
            table = metrics_table(df["benchmark"], {"WRF-Hydro": df["wrf"], "LSTM": df["hybrid"]})
            table.to_csv(outdir / "Table_S3_domain_metrics_from_predictions.csv", index=False)
    if args.training:
        generated.append(plot_training_convergence(args.training, outdir))
    if args.pca:
        generated.append(plot_pca(args.pca, outdir))
    if args.baseline:
        generated.append(plot_domain_baseline_comparison(args.baseline, outdir))
    if args.spatial_npz:
        generated.append(plot_spatial_frequency_template(args.spatial_npz, outdir))

    print("Generated files:")
    for path in generated:
        print(f" - {path}")
    print(f"Output directory: {outdir}")

if __name__ == "__main__":
    main()
