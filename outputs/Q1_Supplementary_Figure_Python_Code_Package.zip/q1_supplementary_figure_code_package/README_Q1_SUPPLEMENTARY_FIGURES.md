# Q1 Supplementary Figure Code Package

This package provides reproducible Python code to generate the eight supplementary figures for the Volta WRF-Hydro–LSTM residual-correction study.

## Core rules built into the script

- G-RUN is always treated as a runoff/reanalysis benchmark, not observed discharge.
- ARIMA is excluded.
- Evaluation Location / EL1 / EL2 point-based language is excluded.
- Q90 is the primary high-flow target.
- Q95 is an extreme-flow sensitivity test only.
- Spatial flood products are treated as benchmark-relative / satellite-supported diagnostics, not full hydraulic inundation validation.

## Install

```bash
pip install numpy pandas matplotlib
```

## Write input templates

```bash
python generate_q1_supplementary_figures.py --write_templates --outdir supp_figures
```

## Generate figures from final files

```bash
python generate_q1_supplementary_figures.py \
  --predictions amjjaso_predictions.csv \
  --training_history lstm_training_history.csv \
  --pca_scores predictor_pca_scores.csv \
  --pca_loadings predictor_pc1_loadings.csv \
  --baseline domain_baseline_metrics.csv \
  --spatial_npz flood_frequency_arrays.npz \
  --spatial_threshold 0.5 \
  --outdir supp_figures
```

## Figure input requirements

### S1 and S3
Prediction CSV columns:
- `benchmark` or `g_run` or `observed` (the script renames this internally to benchmark)
- `wrf` or `wrf_hydro`
- `hybrid` or `lstm_hybrid`
- optional `date`

### S2
Training-history CSV columns:
- `epoch`
- `training_loss`
- `validation_loss`

### S4
PCA scores CSV:
- `pc1`
- `pc2`
- `residual_magnitude`

PCA loadings CSV:
- `predictor`
- `pc1_loading_abs`

### S7
NPZ file arrays:
- `benchmark_freq`
- `wrf_freq`
- `hybrid_freq`
- optional `mask`, `lon_min`, `lon_max`, `lat_min`, `lat_max`

### S8
Baseline CSV rows:
- Standalone WRF-Hydro
- Persistence
- LR-AR
- Hybrid WRF-Hydro–LSTM

Columns:
- RMSE, MAE, R2, NSE, KGE, Residual variance, Lag-1 ACF, RMSE reduction (%)

Use `--allow_pending_baseline` only to make a clearly marked template when Persistence and LR-AR values are not yet computed.
Do not submit a pending-template Fig. S8 as final.

## Outputs

Each generated figure is saved as:
- PNG at 600 dpi
- PDF
- SVG

These formats support both submission review and final production workflows.
