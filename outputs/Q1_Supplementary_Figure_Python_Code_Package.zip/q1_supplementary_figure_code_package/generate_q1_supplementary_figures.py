#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
generate_q1_supplementary_figures.py

Purpose
-------
Generate the eight supplementary figures for:

"Multi-source assessment of a hybrid WRF-Hydro–LSTM residual-correction framework
for AMJJASO high-flow reconstruction in the regulated Volta River Basin"

This script is designed for Q1 journal submission standards:
- figures are generated from data and corrected manuscript values;
- G-RUN is treated only as a runoff/reanalysis benchmark;
- no ARIMA model is included;
- no Evaluation Location / EL1 / EL2 point-based framing is used;
- all outputs are reproducible and exported as PNG, PDF, and SVG.

Supplementary figures generated
-------------------------------
Fig. S1  Flow-duration comparison for AMJJASO benchmark-relative discharge.
Fig. S2  LSTM benchmark-relative residual-learning convergence.
Fig. S3  Event-scale benchmark-relative hydrograph diagnostics.
Fig. S4  Predictor PCA / feature-space diagnostics.
Fig. S5  Corrected AMJJASO RMSE comparison.
Fig. S6  Aggregate model-performance radar chart using corrected metrics.
Fig. S7  Extended benchmark-relative spatial flood-frequency maps.
Fig. S8  Domain-based residual-baseline comparison excluding ARIMA.

Required Python packages
------------------------
numpy, pandas, matplotlib

Optional:
rasterio, only if you adapt the spatial routine to GeoTIFF input.
The default spatial routine uses an NPZ file to avoid hidden GIS dependencies.

Author note
-----------
Do not submit AI-generated figure images. Submit figures produced by this script
from the final domain-based data, together with the code and input files.

"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

import numpy as np
import pandas as pd
import matplotlib as mpl
import matplotlib.pyplot as plt


# =============================================================================
# Corrected values from the revised main manuscript
# =============================================================================

CORRECTED = {
    "amjjaso_rmse_wrf": 1.411,
    "amjjaso_rmse_hybrid": 0.844,
    "amjjaso_rmse_reduction": 40.22,

    "amjjaso_mae_wrf": 1.091,
    "amjjaso_mae_hybrid": 0.606,
    "r2_wrf": 0.610,
    "r2_hybrid": 0.851,
    "nse_wrf": 0.574,
    "nse_hybrid": 0.848,
    "kge_wrf": 0.776,
    "kge_hybrid": 0.845,

    "q90_rmse_wrf": 2.284,
    "q90_rmse_hybrid": 1.693,
    "q90_rmse_reduction": 25.88,

    "q95_rmse_wrf": 2.486,
    "q95_rmse_hybrid": 2.102,
    "q95_rmse_reduction": 15.47,

    "flood_area_rmse_wrf": 1680.0,
    "flood_area_rmse_hybrid": 1420.0,
    "spatial_disagreement_wrf": 0.34,
    "spatial_disagreement_hybrid": 0.27,

    "benchmark_mean_flooded_area": 4591.0,
    "wrf_mean_flooded_area": 6200.0,
    "hybrid_mean_flooded_area": 5967.0,
    "mean_overestimation_reduction": 233.0,

    "trend_benchmark": 46.148,
    "trend_wrf": 65.280,
    "trend_hybrid": 62.678,
    "trend_bias_reduction": 13.60,
}


# =============================================================================
# General style and utility functions
# =============================================================================

def setup_style() -> None:
    """Set a restrained journal-style Matplotlib theme."""
    mpl.rcParams.update({
        "font.family": "DejaVu Sans",
        "font.size": 9,
        "axes.titlesize": 10,
        "axes.labelsize": 9,
        "xtick.labelsize": 8,
        "ytick.labelsize": 8,
        "legend.fontsize": 8,
        "figure.titlesize": 11,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "axes.linewidth": 0.8,
        "xtick.major.width": 0.8,
        "ytick.major.width": 0.8,
        "grid.linewidth": 0.5,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "svg.fonttype": "none",
    })


def ensure_outdir(outdir: str | Path) -> Path:
    outdir = Path(outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    return outdir


def save_figure(fig: mpl.figure.Figure, outdir: Path, stem: str, dpi: int = 600) -> List[Path]:
    """Save a figure in journal-friendly raster and vector formats."""
    outdir = ensure_outdir(outdir)
    paths = [
        outdir / f"{stem}.png",
        outdir / f"{stem}.pdf",
        outdir / f"{stem}.svg",
    ]
    fig.savefig(paths[0], dpi=dpi, bbox_inches="tight")
    fig.savefig(paths[1], bbox_inches="tight")
    fig.savefig(paths[2], bbox_inches="tight")
    plt.close(fig)
    return paths


def normalize_prediction_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Normalize likely column names without altering values.

    Required normalized columns:
        benchmark, wrf, hybrid
    Optional:
        date
    """
    aliases = {
        "benchmark": [
            "benchmark", "g_run", "grun", "g-run", "g_run_benchmark",
            "q_g_run", "q_bench", "q_benchmark", "observed"
        ],
        "wrf": [
            "wrf", "wrf_hydro", "wrf-hydro", "q_wrf",
            "standalone", "standalone_wrf_hydro", "wrfhydro"
        ],
        "hybrid": [
            "hybrid", "lstm_hybrid", "wrf_lstm", "wrf-hydro-lstm",
            "q_hybrid", "hybrid_wrf_hydro_lstm"
        ],
        "date": ["date", "time", "datetime", "timestamp", "time_index", "record_index"],
    }

    lower_to_original = {c.lower().strip(): c for c in df.columns}
    rename = {}
    for target, options in aliases.items():
        for opt in options:
            if opt in lower_to_original:
                rename[lower_to_original[opt]] = target
                break
    out = df.rename(columns=rename)
    return out


def validate_prediction_columns(df: pd.DataFrame) -> None:
    required = {"benchmark", "wrf", "hybrid"}
    missing = required.difference(df.columns)
    if missing:
        raise ValueError(
            f"Prediction CSV is missing columns {sorted(missing)} after alias normalization. "
            f"Columns found: {df.columns.tolist()}"
        )


def rmse(obs: Iterable[float], sim: Iterable[float]) -> float:
    obs = np.asarray(obs, dtype=float)
    sim = np.asarray(sim, dtype=float)
    return float(np.sqrt(np.nanmean((obs - sim) ** 2)))


def mae(obs: Iterable[float], sim: Iterable[float]) -> float:
    obs = np.asarray(obs, dtype=float)
    sim = np.asarray(sim, dtype=float)
    return float(np.nanmean(np.abs(obs - sim)))


def r2(obs: Iterable[float], sim: Iterable[float]) -> float:
    obs = np.asarray(obs, dtype=float)
    sim = np.asarray(sim, dtype=float)
    mask = np.isfinite(obs) & np.isfinite(sim)
    if mask.sum() < 3:
        return np.nan
    return float(np.corrcoef(obs[mask], sim[mask])[0, 1] ** 2)


def nse(obs: Iterable[float], sim: Iterable[float]) -> float:
    obs = np.asarray(obs, dtype=float)
    sim = np.asarray(sim, dtype=float)
    den = np.nansum((obs - np.nanmean(obs)) ** 2)
    if den == 0:
        return np.nan
    return float(1.0 - np.nansum((obs - sim) ** 2) / den)


def kge(obs: Iterable[float], sim: Iterable[float]) -> float:
    obs = np.asarray(obs, dtype=float)
    sim = np.asarray(sim, dtype=float)
    mask = np.isfinite(obs) & np.isfinite(sim)
    if mask.sum() < 3:
        return np.nan
    o = obs[mask]
    s = sim[mask]
    corr = np.corrcoef(o, s)[0, 1]
    alpha = np.std(s, ddof=1) / np.std(o, ddof=1) if np.std(o, ddof=1) != 0 else np.nan
    beta = np.mean(s) / np.mean(o) if np.mean(o) != 0 else np.nan
    return float(1.0 - np.sqrt((corr - 1) ** 2 + (alpha - 1) ** 2 + (beta - 1) ** 2))


def lag1_acf(values: Iterable[float]) -> float:
    x = np.asarray(values, dtype=float)
    x = x[np.isfinite(x)]
    if len(x) < 3:
        return np.nan
    return float(np.corrcoef(x[:-1], x[1:])[0, 1])


def load_predictions(path: str | Path) -> pd.DataFrame:
    df = normalize_prediction_columns(pd.read_csv(path))
    validate_prediction_columns(df)
    return df


def compute_domain_metrics(df: pd.DataFrame) -> pd.DataFrame:
    """Compute benchmark-relative metrics from a prediction table."""
    validate_prediction_columns(df)
    rows = []
    for model, col in [("Standalone WRF-Hydro", "wrf"), ("Hybrid WRF-Hydro–LSTM", "hybrid")]:
        residual = df["benchmark"].to_numpy(dtype=float) - df[col].to_numpy(dtype=float)
        rows.append({
            "Model": model,
            "RMSE": rmse(df["benchmark"], df[col]),
            "MAE": mae(df["benchmark"], df[col]),
            "R2": r2(df["benchmark"], df[col]),
            "NSE": nse(df["benchmark"], df[col]),
            "KGE": kge(df["benchmark"], df[col]),
            "Residual variance": float(np.nanvar(residual)),
            "Lag-1 ACF": lag1_acf(residual),
        })
    out = pd.DataFrame(rows)
    wrf_rmse = out.loc[out["Model"].eq("Standalone WRF-Hydro"), "RMSE"].iloc[0]
    out["RMSE reduction (%)"] = (wrf_rmse - out["RMSE"]) / wrf_rmse * 100.0
    return out


# =============================================================================
# Fig. S1: Flow-duration comparison
# =============================================================================

def plot_s1_flow_duration(predictions_csv: str | Path, outdir: str | Path) -> List[Path]:
    df = load_predictions(predictions_csv).dropna(subset=["benchmark", "wrf", "hybrid"])
    setup_style()

    fig, ax = plt.subplots(figsize=(7.2, 4.8))
    series = [
        ("benchmark", "G-RUN runoff/reanalysis benchmark"),
        ("wrf", "Standalone WRF-Hydro"),
        ("hybrid", "Hybrid WRF-Hydro–LSTM"),
    ]
    for col, label in series:
        values = np.sort(df[col].to_numpy(dtype=float))[::-1]
        exc = np.arange(1, len(values) + 1) / (len(values) + 1) * 100.0
        ax.plot(exc, values, linewidth=1.7, label=label)

    ax.set_yscale("log")
    ax.set_xlabel("Exceedance probability (%)")
    ax.set_ylabel("Benchmark-relative discharge")
    ax.set_title("Fig. S1. Flow-duration comparison for AMJJASO benchmark-relative discharge")
    ax.grid(True, which="both", alpha=0.25)
    ax.legend(frameon=False, loc="best")
    fig.text(
        0.5, -0.01,
        "G-RUN is used as a runoff/reanalysis benchmark, not observed discharge.",
        ha="center", va="top", fontsize=8
    )
    fig.tight_layout()
    return save_figure(fig, ensure_outdir(outdir), "Fig_S1_flow_duration_AMJJASO_benchmark_relative")


# =============================================================================
# Fig. S2: LSTM convergence
# =============================================================================

def plot_s2_lstm_convergence(training_csv: str | Path, outdir: str | Path) -> List[Path]:
    df = pd.read_csv(training_csv)
    lower_cols = {c.lower().strip(): c for c in df.columns}

    def get_col(*names: str) -> str:
        for n in names:
            if n in lower_cols:
                return lower_cols[n]
        raise ValueError(f"Training CSV missing one of: {names}. Found {df.columns.tolist()}")

    epoch_col = lower_cols.get("epoch", None)
    train_col = get_col("training_loss", "train_loss", "loss_train", "mse_train")
    val_col = get_col("validation_loss", "val_loss", "loss_validation", "mse_val")

    epoch = df[epoch_col].to_numpy() if epoch_col else np.arange(1, len(df) + 1)
    setup_style()

    fig, ax = plt.subplots(figsize=(7.2, 4.8))
    ax.plot(epoch, df[train_col], linewidth=1.8, label="Training loss")
    ax.plot(epoch, df[val_col], linewidth=1.8, label="Validation loss")
    ax.set_xlabel("Epoch")
    ax.set_ylabel("Loss (MSE)")
    ax.set_title("Fig. S2. LSTM benchmark-relative residual-learning convergence")
    ax.grid(True, alpha=0.25)
    ax.legend(frameon=False)

    config_text = "30-day lookback\n64 hidden units\nDropout = 0.2\nAdam optimizer"
    ax.text(
        0.98, 0.72, config_text,
        transform=ax.transAxes, ha="right", va="top",
        bbox=dict(boxstyle="round,pad=0.35", facecolor="white", edgecolor="0.6"),
        fontsize=8
    )
    fig.tight_layout()
    return save_figure(fig, ensure_outdir(outdir), "Fig_S2_LSTM_residual_learning_convergence")


# =============================================================================
# Fig. S3: Event-scale hydrograph diagnostics
# =============================================================================

def plot_s3_event_hydrograph(
    predictions_csv: str | Path,
    outdir: str | Path,
    center_index: Optional[int] = None,
    window: int = 80
) -> List[Path]:
    df = load_predictions(predictions_csv).dropna(subset=["benchmark", "wrf", "hybrid"]).reset_index(drop=True)

    if center_index is None:
        center_index = int(np.nanargmax(df["benchmark"].to_numpy(dtype=float)))
    half = max(5, int(window // 2))
    start = max(0, center_index - half)
    end = min(len(df), center_index + half)
    sub = df.iloc[start:end].reset_index(drop=True)
    x = np.arange(len(sub))
    q90 = np.nanpercentile(df["benchmark"], 90)

    setup_style()
    fig, axes = plt.subplots(2, 1, figsize=(7.2, 5.6), sharex=False)

    axes[0].plot(x, sub["benchmark"], linewidth=1.7, label="G-RUN runoff/reanalysis benchmark")
    axes[0].plot(x, sub["wrf"], linewidth=1.4, label="Standalone WRF-Hydro")
    axes[0].plot(x, sub["hybrid"], linewidth=1.7, label="Hybrid WRF-Hydro–LSTM")
    axes[0].axhline(q90, linestyle="--", linewidth=1.1, label="AMJJASO Q90")
    axes[0].set_ylabel("Benchmark-relative discharge")
    axes[0].set_title("(a) Representative AMJJASO event window")
    axes[0].grid(True, alpha=0.25)
    axes[0].legend(frameon=False, ncol=2, fontsize=7)

    # Zoom around local maximum inside the selected window.
    local_max = int(np.nanargmax(sub["benchmark"].to_numpy(dtype=float)))
    z0 = max(0, local_max - max(8, int(window * 0.18)))
    z1 = min(len(sub), local_max + max(12, int(window * 0.22)))
    z = sub.iloc[z0:z1].reset_index(drop=True)
    zx = np.arange(len(z))

    axes[1].plot(zx, z["benchmark"], linewidth=1.7, label="G-RUN runoff/reanalysis benchmark")
    axes[1].plot(zx, z["wrf"], linewidth=1.4, label="Standalone WRF-Hydro")
    axes[1].plot(zx, z["hybrid"], linewidth=1.7, label="Hybrid WRF-Hydro–LSTM")
    axes[1].axhline(q90, linestyle="--", linewidth=1.1, label="AMJJASO Q90")
    axes[1].set_xlabel("Event-window record index")
    axes[1].set_ylabel("Benchmark-relative discharge")
    axes[1].set_title("(b) Zoomed event window")
    axes[1].grid(True, alpha=0.25)

    fig.suptitle("Fig. S3. Event-scale benchmark-relative hydrograph diagnostics", y=1.02)
    fig.text(
        0.5, -0.01,
        "Benchmark-relative event diagnostics; not independent discharge validation.",
        ha="center", va="top", fontsize=8
    )
    fig.tight_layout()
    return save_figure(fig, ensure_outdir(outdir), "Fig_S3_event_scale_benchmark_relative_hydrograph")


# =============================================================================
# Fig. S4: Predictor feature-space diagnostics
# =============================================================================

def plot_s4_predictor_feature_space(
    pca_scores_csv: str | Path,
    pca_loadings_csv: str | Path,
    outdir: str | Path
) -> List[Path]:
    scores = pd.read_csv(pca_scores_csv)
    loadings = pd.read_csv(pca_loadings_csv)

    score_alias = {c.lower().strip(): c for c in scores.columns}
    load_alias = {c.lower().strip(): c for c in loadings.columns}

    def scol(*names: str) -> str:
        for n in names:
            if n in score_alias:
                return score_alias[n]
        raise ValueError(f"PCA scores CSV missing one of {names}. Found {scores.columns.tolist()}")

    def lcol(*names: str) -> str:
        for n in names:
            if n in load_alias:
                return load_alias[n]
        raise ValueError(f"PCA loadings CSV missing one of {names}. Found {loadings.columns.tolist()}")

    pc1 = scol("pc1", "pc_1", "component_1")
    pc2 = scol("pc2", "pc_2", "component_2")
    residual_mag = scol("residual_magnitude", "abs_residual", "absolute_residual", "benchmark_relative_residual_magnitude")

    predictor_col = lcol("predictor", "variable", "feature")
    loading_col = lcol("pc1_loading_abs", "abs_pc1_loading", "standardized_absolute_pc1_loading", "loading")

    loadings = loadings.copy()
    loadings[loading_col] = np.abs(loadings[loading_col].astype(float))
    if loadings[loading_col].max() > 0:
        loadings["standardized_loading"] = loadings[loading_col] / loadings[loading_col].max()
    else:
        loadings["standardized_loading"] = loadings[loading_col]

    setup_style()
    fig, axes = plt.subplots(1, 2, figsize=(8.4, 4.8), gridspec_kw={"width_ratios": [1.1, 1.0]})

    scatter = axes[0].scatter(
        scores[pc1], scores[pc2],
        c=scores[residual_mag], s=16, alpha=0.72,
        cmap="coolwarm", edgecolor="none"
    )
    axes[0].axhline(0, linestyle="--", linewidth=0.8, color="0.6")
    axes[0].axvline(0, linestyle="--", linewidth=0.8, color="0.6")
    axes[0].set_xlabel("PC1 (standardized)")
    axes[0].set_ylabel("PC2 (standardized)")
    axes[0].set_title("(a) Standardized predictor space\nunder AMJJASO conditions")
    axes[0].grid(False)

    cbar = fig.colorbar(scatter, ax=axes[0], orientation="horizontal", pad=0.20, fraction=0.08)
    cbar.set_label("Benchmark-relative residual magnitude")
    cbar.ax.text(0.0, -1.65, "Lower", transform=cbar.ax.transAxes, ha="left", va="top", fontsize=7)
    cbar.ax.text(1.0, -1.65, "Higher", transform=cbar.ax.transAxes, ha="right", va="top", fontsize=7)

    ordered = loadings.sort_values("standardized_loading", ascending=True)
    axes[1].barh(ordered[predictor_col], ordered["standardized_loading"])
    axes[1].set_xlim(0, 1.05)
    axes[1].set_xlabel("Standardized absolute PC1 loading")
    axes[1].set_title("(b) Relative contribution of major predictors\n(PC1 loading magnitude)")
    axes[1].grid(True, axis="x", alpha=0.25)

    fig.suptitle("Fig. S4. Predictor feature-space diagnostics", y=1.03)
    fig.text(
        0.5, -0.01,
        "Predictor feature-space diagnostics supporting benchmark-relative residual learning under AMJJASO conditions.",
        ha="center", va="top", fontsize=8
    )
    fig.tight_layout()
    return save_figure(fig, ensure_outdir(outdir), "Fig_S4_predictor_feature_space_diagnostics")


# =============================================================================
# Fig. S5: Corrected AMJJASO RMSE comparison
# =============================================================================

def plot_s5_corrected_rmse(outdir: str | Path) -> List[Path]:
    setup_style()
    fig, ax = plt.subplots(figsize=(6.2, 4.2))

    labels = ["Standalone WRF-Hydro", "Hybrid WRF-Hydro–LSTM"]
    values = [CORRECTED["amjjaso_rmse_wrf"], CORRECTED["amjjaso_rmse_hybrid"]]
    x = np.arange(len(labels))

    bars = ax.bar(x, values, width=0.55)
    for xi, val in zip(x, values):
        ax.text(xi, val + 0.04, f"{val:.3f}", ha="center", va="bottom")

    ax.annotate(
        "AMJJASO RMSE reduction = 40.22%",
        xy=(1, CORRECTED["amjjaso_rmse_hybrid"]),
        xytext=(0.58, 1.48),
        arrowprops=dict(arrowstyle="->", linewidth=1.0),
        bbox=dict(boxstyle="round,pad=0.35", facecolor="white", edgecolor="0.5"),
        fontsize=9
    )
    ax.set_xticks(x)
    ax.set_xticklabels(labels)
    ax.set_ylabel("RMSE (benchmark-relative units)")
    ax.set_ylim(0, 1.75)
    ax.set_title("Fig. S5. Corrected AMJJASO benchmark-relative RMSE comparison")
    ax.grid(True, axis="y", alpha=0.25)

    fig.text(
        0.5, -0.01,
        "Comparison against the G-RUN runoff/reanalysis benchmark during AMJJASO.",
        ha="center", va="top", fontsize=8
    )
    fig.tight_layout()
    return save_figure(fig, ensure_outdir(outdir), "Fig_S5_corrected_AMJJASO_RMSE_comparison")


# =============================================================================
# Fig. S6: Aggregate model-performance radar chart
# =============================================================================

def plot_s6_aggregate_radar(outdir: str | Path) -> List[Path]:
    """Plot corrected improvement percentages only; no fabricated standalone scores."""
    improvement = {
        "AMJJASO RMSE": CORRECTED["amjjaso_rmse_reduction"],
        "Q90 RMSE": CORRECTED["q90_rmse_reduction"],
        "Q95 RMSE\nsensitivity": CORRECTED["q95_rmse_reduction"],
        "Flood-area\nRMSE": (CORRECTED["flood_area_rmse_wrf"] - CORRECTED["flood_area_rmse_hybrid"])
                              / CORRECTED["flood_area_rmse_wrf"] * 100.0,
        "Spatial\ndisagreement": (CORRECTED["spatial_disagreement_wrf"] - CORRECTED["spatial_disagreement_hybrid"])
                                / CORRECTED["spatial_disagreement_wrf"] * 100.0,
        "Flooded-area\noverestimation": CORRECTED["mean_overestimation_reduction"]
                                   / (CORRECTED["wrf_mean_flooded_area"] - CORRECTED["benchmark_mean_flooded_area"]) * 100.0,
    }

    labels = list(improvement.keys())
    values_pct = np.array(list(improvement.values()), dtype=float)
    values = np.clip(values_pct / 50.0, 0, 1)  # 50% reference scaling
    angles = np.linspace(0, 2 * np.pi, len(labels), endpoint=False)
    angles_closed = np.r_[angles, angles[0]]
    values_closed = np.r_[values, values[0]]

    setup_style()
    fig = plt.figure(figsize=(6.2, 6.2))
    ax = fig.add_subplot(111, polar=True)
    ax.plot(angles_closed, values_closed, marker="o", linewidth=1.8, label="Hybrid improvement")
    ax.fill(angles_closed, values_closed, alpha=0.18)
    ax.set_xticks(angles)
    ax.set_xticklabels(labels, fontsize=8)
    ax.set_ylim(0, 1.0)
    ax.set_yticks([0.2, 0.4, 0.6, 0.8, 1.0])
    ax.set_yticklabels(["10", "20", "30", "40", "50%"], fontsize=7)
    ax.set_title("Fig. S6. Aggregate AMJJASO model-performance synthesis", pad=20)
    ax.legend(loc="upper right", bbox_to_anchor=(1.30, 1.10), frameon=False)

    # Add text values around the figure using axes coordinates.
    summary = (
        "Improvement values: AMJJASO 40.22%; Q90 25.88%; Q95 15.47%; "
        "flood-area RMSE 15.48%; spatial disagreement 20.59%; "
        "flooded-area overestimation 14.48%."
    )
    fig.text(0.5, 0.02, summary, ha="center", va="bottom", fontsize=7, wrap=True)
    fig.tight_layout()
    return save_figure(fig, ensure_outdir(outdir), "Fig_S6_aggregate_AMJJASO_model_performance_radar")


# =============================================================================
# Fig. S7: Extended benchmark-relative spatial flood-frequency maps
# =============================================================================

def plot_s7_spatial_frequency_maps(
    spatial_npz: str | Path,
    outdir: str | Path,
    threshold: Optional[float] = None
) -> List[Path]:
    """Plot spatial flood-frequency maps from real gridded arrays.

    NPZ file must contain:
        benchmark_freq, wrf_freq, hybrid_freq

    Optional:
        mask              boolean or 0/1 array; True/1 means valid analysis cell
        lon_min, lon_max, lat_min, lat_max
    """
    data = np.load(spatial_npz)
    required = ["benchmark_freq", "wrf_freq", "hybrid_freq"]
    missing = [k for k in required if k not in data]
    if missing:
        raise ValueError(f"Spatial NPZ missing arrays: {missing}")

    bench = data["benchmark_freq"].astype(float)
    wrf = data["wrf_freq"].astype(float)
    hyb = data["hybrid_freq"].astype(float)

    valid = np.isfinite(bench) & np.isfinite(wrf) & np.isfinite(hyb)
    if "mask" in data:
        valid &= data["mask"].astype(bool)

    bench_plot = np.where(valid, bench, np.nan)
    wrf_diff = np.where(valid, wrf - bench, np.nan)
    hyb_diff = np.where(valid, hyb - bench, np.nan)

    wrf_rmse = rmse(bench[valid], wrf[valid])
    hyb_rmse = rmse(bench[valid], hyb[valid])
    rmse_reduction = (wrf_rmse - hyb_rmse) / wrf_rmse * 100.0 if wrf_rmse != 0 else np.nan

    if threshold is not None:
        bench_bin = bench[valid] > threshold
        wrf_bin = wrf[valid] > threshold
        hyb_bin = hyb[valid] > threshold
        wrf_dis = float(np.mean(wrf_bin != bench_bin))
        hyb_dis = float(np.mean(hyb_bin != bench_bin))
        dis_reduction = (wrf_dis - hyb_dis) / wrf_dis * 100.0 if wrf_dis != 0 else np.nan
    else:
        wrf_dis = np.nan
        hyb_dis = np.nan
        dis_reduction = np.nan

    extent = None
    if all(k in data for k in ["lon_min", "lon_max", "lat_min", "lat_max"]):
        extent = [float(data["lon_min"]), float(data["lon_max"]), float(data["lat_min"]), float(data["lat_max"])]

    setup_style()
    fig, axes = plt.subplots(2, 3, figsize=(9.0, 5.8))
    ax = axes.ravel()

    im0 = ax[0].imshow(bench_plot, origin="lower", extent=extent)
    ax[0].set_title("(a) Benchmark-derived flood frequency")
    c0 = fig.colorbar(im0, ax=ax[0], fraction=0.046, pad=0.03)
    c0.set_label("Events per year", fontsize=8)

    vmax = np.nanpercentile(np.abs(np.r_[wrf_diff.ravel(), hyb_diff.ravel()]), 98)
    vmax = vmax if np.isfinite(vmax) and vmax > 0 else 1.0
    im1 = ax[1].imshow(wrf_diff, origin="lower", extent=extent, cmap="RdBu_r", vmin=-vmax, vmax=vmax)
    ax[1].set_title("(b) WRF-Hydro minus benchmark")
    c1 = fig.colorbar(im1, ax=ax[1], fraction=0.046, pad=0.03)
    c1.set_label("Frequency difference", fontsize=8)

    im2 = ax[2].imshow(hyb_diff, origin="lower", extent=extent, cmap="RdBu_r", vmin=-vmax, vmax=vmax)
    ax[2].set_title("(c) Hybrid minus benchmark")
    c2 = fig.colorbar(im2, ax=ax[2], fraction=0.046, pad=0.03)
    c2.set_label("Frequency difference", fontsize=8)

    for a in ax[:3]:
        a.set_xticks([])
        a.set_yticks([])

    # Bottom summary panels computed from arrays.
    ax[3].bar(["WRF-Hydro", "Hybrid"], [wrf_rmse, hyb_rmse])
    ax[3].set_title("(d) Flood-frequency RMSE")
    ax[3].set_ylabel("RMSE")
    ax[3].grid(True, axis="y", alpha=0.25)

    ax[4].bar(["RMSE reduction"], [rmse_reduction])
    ax[4].set_title("(e) Hybrid RMSE reduction")
    ax[4].set_ylim(0, max(10, min(100, rmse_reduction * 1.4 if np.isfinite(rmse_reduction) else 50)))
    ax[4].set_ylabel("Reduction (%)")
    ax[4].grid(True, axis="y", alpha=0.25)
    if np.isfinite(rmse_reduction):
        ax[4].text(0, rmse_reduction + 1, f"{rmse_reduction:.1f}%", ha="center")

    if threshold is not None and np.isfinite(wrf_dis):
        ax[5].bar(["WRF-Hydro", "Hybrid"], [wrf_dis, hyb_dis])
        ax[5].set_title("(f) Spatial disagreement")
        ax[5].set_ylabel("Disagreement")
        if np.isfinite(dis_reduction):
            ax[5].text(0.5, max(wrf_dis, hyb_dis) * 1.05, f"Reduction = {dis_reduction:.1f}%", ha="center")
    else:
        ax[5].axis("off")
        ax[5].text(
            0.5, 0.5,
            "Thresholded spatial disagreement\nrequires --spatial_threshold",
            ha="center", va="center"
        )

    fig.suptitle("Fig. S7. Extended benchmark-relative spatial flood-frequency diagnostics", y=1.02)
    fig.text(
        0.5, -0.01,
        "Lake Volta and perennial water should be excluded using the JRC Global Surface Water mask; "
        "diagnostics are benchmark-relative and not hydraulic inundation validation.",
        ha="center", va="top", fontsize=8, wrap=True
    )
    fig.tight_layout()
    return save_figure(fig, ensure_outdir(outdir), "Fig_S7_extended_benchmark_relative_spatial_frequency")


# =============================================================================
# Fig. S8: Domain-based residual-baseline comparison excluding ARIMA
# =============================================================================

def plot_s8_domain_baseline(
    baseline_csv: str | Path,
    outdir: str | Path,
    allow_pending: bool = False
) -> List[Path]:
    df = pd.read_csv(baseline_csv)
    if "Model" not in df.columns and "model" in df.columns:
        df = df.rename(columns={"model": "Model"})

    if "Model" not in df.columns:
        raise ValueError("Baseline CSV must contain a 'Model' column.")

    # Exclude any accidental ARIMA row.
    df = df[~df["Model"].astype(str).str.lower().str.contains("arima", na=False)].copy()

    required_models = ["Standalone WRF-Hydro", "Persistence", "LR-AR", "Hybrid WRF-Hydro–LSTM"]
    canonical = {
        "standalone wrf-hydro": "Standalone WRF-Hydro",
        "wrf-hydro": "Standalone WRF-Hydro",
        "persistence": "Persistence",
        "persistence correction": "Persistence",
        "lr-ar": "LR-AR",
        "lr–ar": "LR-AR",
        "linear autoregressive": "LR-AR",
        "lstm": "Hybrid WRF-Hydro–LSTM",
        "hybrid": "Hybrid WRF-Hydro–LSTM",
        "hybrid wrf-hydro-lstm": "Hybrid WRF-Hydro–LSTM",
        "hybrid wrf-hydro–lstm": "Hybrid WRF-Hydro–LSTM",
    }

    def canon_name(x: str) -> str:
        key = str(x).strip().lower()
        return canonical.get(key, x)

    df["Model"] = df["Model"].apply(canon_name)

    missing_rows = [m for m in required_models if m not in df["Model"].tolist()]
    if missing_rows:
        raise ValueError(f"Baseline CSV missing model rows: {missing_rows}")

    metrics = ["RMSE", "MAE", "R2", "NSE", "KGE", "Residual variance", "Lag-1 ACF"]
    alt_names = {
        "R2": ["R²", "r2", "R^2"],
        "Residual variance": ["residual_variance", "Residual variance"],
        "Lag-1 ACF": ["lag1_acf", "Lag-1 ACF", "Lag1 ACF"],
    }

    # Normalize metric columns where possible.
    for metric, aliases in alt_names.items():
        if metric not in df.columns:
            for a in aliases:
                if a in df.columns:
                    df = df.rename(columns={a: metric})
                    break

    if "RMSE" not in df.columns and "rmse" in df.columns:
        df = df.rename(columns={"rmse": "RMSE"})
    if "MAE" not in df.columns and "mae" in df.columns:
        df = df.rename(columns={"mae": "MAE"})
    if "NSE" not in df.columns and "nse" in df.columns:
        df = df.rename(columns={"nse": "NSE"})
    if "KGE" not in df.columns and "kge" in df.columns:
        df = df.rename(columns={"kge": "KGE"})

    order = {m: i for i, m in enumerate(required_models)}
    df["order"] = df["Model"].map(order)
    df = df.sort_values("order")

    if "RMSE" not in df.columns:
        raise ValueError("Baseline CSV must contain an RMSE column.")

    pending = df[df["RMSE"].isna()]["Model"].tolist()
    if pending and not allow_pending:
        raise ValueError(
            "Cannot generate final Fig. S8 because RMSE is missing for: "
            + ", ".join(pending)
            + ". Populate from final domain-based held-out predictions first, "
              "or use --allow_pending to create a clearly marked template."
        )

    setup_style()
    fig, ax = plt.subplots(figsize=(7.6, 4.8))

    x = np.arange(len(df))
    rmse_vals = pd.to_numeric(df["RMSE"], errors="coerce").to_numpy(dtype=float)

    finite = np.isfinite(rmse_vals)
    bars = ax.bar(x[finite], rmse_vals[finite], width=0.58)
    for xi, val in zip(x[finite], rmse_vals[finite]):
        ax.text(xi, val + 0.04, f"{val:.3f}", ha="center", va="bottom", fontsize=8)

    if not np.all(finite):
        for xi, val in zip(x[~finite], rmse_vals[~finite]):
            ax.text(
                xi, 0.15,
                "to be populated\nfrom final\npredictions",
                ha="center", va="bottom", fontsize=7
            )
            ax.plot([xi - 0.25, xi + 0.25], [0.05, 0.05], color="0.3", linewidth=1.0)
            ax.plot([xi - 0.25, xi + 0.25], [0.30, 0.30], color="0.3", linewidth=1.0)

    ax.set_xticks(x)
    ax.set_xticklabels([
        "Standalone\nWRF-Hydro",
        "Persistence\ncorrection",
        "LR–AR\ncorrection",
        "Hybrid\nWRF-Hydro–LSTM"
    ])
    ax.set_ylabel("RMSE (benchmark-relative units)")
    ax.set_title("Fig. S8. Domain-based AMJJASO residual-baseline comparison")
    ax.grid(True, axis="y", alpha=0.25)

    if "RMSE reduction (%)" in df.columns:
        hyb_row = df[df["Model"].eq("Hybrid WRF-Hydro–LSTM")]
        if len(hyb_row) and np.isfinite(pd.to_numeric(hyb_row["RMSE reduction (%)"], errors="coerce").iloc[0]):
            val = float(hyb_row["RMSE reduction (%)"].iloc[0])
            ax.text(
                0.98, 0.92,
                f"Hybrid RMSE reduction\n= {val:.2f}%",
                transform=ax.transAxes,
                ha="right", va="top",
                bbox=dict(boxstyle="round,pad=0.35", facecolor="white", edgecolor="0.5"),
                fontsize=8
            )

    fig.text(
        0.5, -0.02,
        "Held-out AMJJASO domain-based residual-baseline comparison. "
        "G-RUN is a runoff/reanalysis benchmark; ARIMA is excluded.",
        ha="center", va="top", fontsize=8, wrap=True
    )

    fig.tight_layout()
    return save_figure(fig, ensure_outdir(outdir), "Fig_S8_domain_based_residual_baseline_excluding_ARIMA")


# =============================================================================
# Templates and command-line runner
# =============================================================================

def write_templates(outdir: str | Path) -> List[Path]:
    outdir = ensure_outdir(outdir)
    paths = []

    prediction_template = pd.DataFrame({
        "date": ["YYYY-MM-DD"],
        "benchmark": ["G-RUN benchmark value"],
        "wrf": ["standalone WRF-Hydro value"],
        "hybrid": ["hybrid WRF-Hydro–LSTM value"],
    })
    p = outdir / "template_predictions_for_S1_S3.csv"
    prediction_template.to_csv(p, index=False)
    paths.append(p)

    training_template = pd.DataFrame({
        "epoch": [1],
        "training_loss": ["training MSE"],
        "validation_loss": ["validation MSE"],
    })
    p = outdir / "template_training_history_for_S2.csv"
    training_template.to_csv(p, index=False)
    paths.append(p)

    scores_template = pd.DataFrame({
        "pc1": ["numeric PC1 score"],
        "pc2": ["numeric PC2 score"],
        "residual_magnitude": ["absolute benchmark-relative residual magnitude"],
    })
    p = outdir / "template_pca_scores_for_S4.csv"
    scores_template.to_csv(p, index=False)
    paths.append(p)

    loadings_template = pd.DataFrame({
        "predictor": ["Precipitation", "Temperature / meteorology", "WRF-Hydro discharge", "Antecedent wetness", "Lagged hydroclimatic states"],
        "pc1_loading_abs": [0.96, 0.71, 0.56, 0.33, 0.14],
    })
    p = outdir / "template_pca_loadings_for_S4.csv"
    loadings_template.to_csv(p, index=False)
    paths.append(p)

    baseline_template = pd.DataFrame({
        "Model": ["Standalone WRF-Hydro", "Persistence", "LR-AR", "Hybrid WRF-Hydro–LSTM"],
        "Correction type": ["None", r"r_hat_t = r_{t-1}", "lagged residuals + Q_WRF(t)", "LSTM residual correction"],
        "RMSE": [CORRECTED["amjjaso_rmse_wrf"], np.nan, np.nan, CORRECTED["amjjaso_rmse_hybrid"]],
        "MAE": [CORRECTED["amjjaso_mae_wrf"], np.nan, np.nan, CORRECTED["amjjaso_mae_hybrid"]],
        "R2": [CORRECTED["r2_wrf"], np.nan, np.nan, CORRECTED["r2_hybrid"]],
        "NSE": [CORRECTED["nse_wrf"], np.nan, np.nan, CORRECTED["nse_hybrid"]],
        "KGE": [CORRECTED["kge_wrf"], np.nan, np.nan, CORRECTED["kge_hybrid"]],
        "Residual variance": [np.nan, np.nan, np.nan, np.nan],
        "Lag-1 ACF": [np.nan, np.nan, np.nan, np.nan],
        "RMSE reduction (%)": [0.0, np.nan, np.nan, CORRECTED["amjjaso_rmse_reduction"]],
    })
    p = outdir / "template_domain_baseline_metrics_for_S8.csv"
    baseline_template.to_csv(p, index=False)
    paths.append(p)

    spatial_readme = outdir / "template_spatial_npz_requirements_for_S7.txt"
    spatial_readme.write_text(
        "Fig. S7 requires a real NPZ file with arrays named:\n"
        "  benchmark_freq, wrf_freq, hybrid_freq\n"
        "Optional arrays:\n"
        "  mask, lon_min, lon_max, lat_min, lat_max\n\n"
        "Lake Volta and perennial water should be excluded using the JRC Global Surface Water mask\n"
        "before calculating or plotting event flood-frequency diagnostics.\n",
        encoding="utf-8"
    )
    paths.append(spatial_readme)

    return paths


def run_all(args: argparse.Namespace) -> List[Path]:
    outdir = ensure_outdir(args.outdir)
    generated: List[Path] = []

    if args.write_templates:
        generated.extend(write_templates(outdir / "input_templates"))

    if args.predictions:
        generated.extend(plot_s1_flow_duration(args.predictions, outdir))
        generated.extend(plot_s3_event_hydrograph(args.predictions, outdir, args.event_center, args.event_window))
        metrics = compute_domain_metrics(load_predictions(args.predictions))
        metrics.to_csv(outdir / "domain_metrics_from_predictions.csv", index=False)

    if args.training_history:
        generated.extend(plot_s2_lstm_convergence(args.training_history, outdir))

    if args.pca_scores and args.pca_loadings:
        generated.extend(plot_s4_predictor_feature_space(args.pca_scores, args.pca_loadings, outdir))

    # These two figures can be generated from accepted corrected values.
    if not args.skip_corrected_summary:
        generated.extend(plot_s5_corrected_rmse(outdir))
        generated.extend(plot_s6_aggregate_radar(outdir))

    if args.spatial_npz:
        generated.extend(plot_s7_spatial_frequency_maps(args.spatial_npz, outdir, args.spatial_threshold))

    if args.baseline:
        generated.extend(plot_s8_domain_baseline(args.baseline, outdir, args.allow_pending_baseline))

    return generated


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Generate Q1-ready supplementary figures S1–S8.")
    p.add_argument("--predictions", help="CSV with benchmark, wrf, and hybrid columns for S1/S3.")
    p.add_argument("--training_history", help="CSV with epoch, training_loss, validation_loss for S2.")
    p.add_argument("--pca_scores", help="CSV with pc1, pc2, residual_magnitude for S4.")
    p.add_argument("--pca_loadings", help="CSV with predictor and pc1_loading_abs for S4.")
    p.add_argument("--spatial_npz", help="NPZ with benchmark_freq, wrf_freq, hybrid_freq for S7.")
    p.add_argument("--spatial_threshold", type=float, default=None, help="Optional flood-frequency threshold for S7 disagreement.")
    p.add_argument("--baseline", help="CSV with domain residual-baseline metrics for S8.")
    p.add_argument("--allow_pending_baseline", action="store_true", help="Allow S8 template figure if Persistence/LR-AR metrics are missing.")
    p.add_argument("--event_center", type=int, default=None, help="Optional center index for event hydrograph window.")
    p.add_argument("--event_window", type=int, default=80, help="Event window length for S3.")
    p.add_argument("--skip_corrected_summary", action="store_true", help="Skip S5 and S6 corrected-summary figures.")
    p.add_argument("--write_templates", action="store_true", help="Write CSV/NPZ input templates.")
    p.add_argument("--outdir", default="supplementary_figures_q1", help="Output directory.")
    return p


def main() -> None:
    args = build_parser().parse_args()
    generated = run_all(args)
    print("Generated files:")
    for path in generated:
        print(f" - {path}")


if __name__ == "__main__":
    main()
